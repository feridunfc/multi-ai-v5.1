from temporalio import activity
from dataclasses import dataclass, field
from pathlib import Path
import json
from typing import Dict, Any, Optional

from multi_ai.llm.parser import CodeParser
from multi_ai.sandbox.filesystem import SandboxFileSystem
from multi_ai.git.client import GitManager
from multi_ai.compliance.analyzer import ComplianceAgent
from multi_ai.core.budget import budget_guard
from multi_ai.core.ledger import ledger
from multi_ai.core.metrics import track_time

# YENI AJANLAR
from multi_ai.agents.researcher import EnhancedResearcherAgent
from multi_ai.agents.architect import EnhancedArchitectAgent
from multi_ai.agents.coder import EnhancedCoderAgent
from multi_ai.agents.supervisor import EnhancedSupervisorAgent
from multi_ai.agents.tester import EnhancedTesterAgent
from multi_ai.agents.debugger import EnhancedDebuggerAgent

@dataclass
class AgentInput:
    task_id: str
    instruction: str
    context: dict

@dataclass
class AgentOutput:
    task_id: str
    result: str
    status: str = 'success'
    file_path: str = ''
    data: Optional[Dict[str, Any]] = field(default_factory=dict)

class AgentActivities:
    # ... (Eski aktiviteler ayni kalacak, sadelesmis hali asagida) ...

    @activity.defn
    async def research_task(self, input: AgentInput) -> AgentOutput:
        # ... (Eski kod ayni)
        agent = EnhancedResearcherAgent()
        res = await agent.conduct_research(input.instruction)
        return AgentOutput(task_id=input.task_id, result='Done', data=res)

    @activity.defn
    async def architect_design(self, input: AgentInput) -> AgentOutput:
        # ... (Eski kod ayni)
        ctx = input.context or {}
        agent = EnhancedArchitectAgent()
        manifest = await agent.create_manifest(ctx.get('research_data', {}), input.instruction)
        return AgentOutput(task_id=input.task_id, result=json.dumps(manifest), data=manifest)

    @activity.defn
    async def coder_implement(self, input: AgentInput) -> AgentOutput:
        # ... (Eski kod ayni)
        ctx = input.context or {}
        manifest = ctx.get('manifest', {})
        artifacts = manifest.get('artifacts', [])
        if not artifacts: artifacts = [{'path': 'main.py', 'purpose': 'Main Logic'}]
        
        agent = EnhancedCoderAgent()
        created_files = []
        for art in artifacts:
            path = await agent.implement_artifact(art, input.task_id)
            created_files.append(path)
            
        return AgentOutput(task_id=input.task_id, result='Coded', file_path=created_files[0])

    # --- YENI: TESTER ---
    @activity.defn
    async def tester_run(self, input: AgentInput) -> AgentOutput:
        activity.logger.info(f'🧪 Tester running: {input.instruction}')
        agent = EnhancedTesterAgent()
        result = agent.run_code(input.instruction)
        
        ledger.record_entry(input.task_id, 'TEST_RUN', result)
        
        if not result['success']:
            return AgentOutput(task_id=input.task_id, result=result['output'], status='failed', data=result)
            
        return AgentOutput(task_id=input.task_id, result='Passed', status='success', data=result)

    # --- YENI: DEBUGGER ---
    @activity.defn
    async def debugger_fix(self, input: AgentInput) -> AgentOutput:
        activity.logger.info(f'🚑 Debugger fixing...')
        
        file_path = input.instruction
        error_log = input.context.get('error_log', '')
        
        # Dosyayi oku
        with open(file_path, 'r', encoding='utf-8') as f:
            broken_code = f.read()
            
        agent = EnhancedDebuggerAgent()
        diagnosis = await agent.diagnose_error(broken_code, error_log)
        
        # Duzeltilmis kodu kaydet
        fixed_code_raw = diagnosis.get('fixed_code', '')
        clean_code = CodeParser.extract_python_code(fixed_code_raw)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(clean_code)
            
        ledger.record_entry(input.task_id, 'DEBUG_FIX', {'file': file_path})
        return AgentOutput(task_id=input.task_id, result='Fixed', file_path=file_path)

    @activity.defn
    async def compliance_check(self, input: AgentInput) -> AgentOutput:
        # ... (Eski kodun aynisi)
        file_path = Path(input.instruction)
        if not file_path.exists(): return AgentOutput(task_id=input.task_id, status='failed', result='Not Found')
        
        with open(file_path, 'r', encoding='utf-8') as f: code = f.read()
        agent = ComplianceAgent()
        rep = agent.analyze_code(code)
        
        if not rep['compliant']:
            return AgentOutput(task_id=input.task_id, status='failed', result=str(rep['violations']))
        return AgentOutput(task_id=input.task_id, result='Passed', file_path=str(file_path))

    @activity.defn
    async def publisher_publish(self, input: AgentInput) -> AgentOutput:
        # ... (Eski kodun aynisi)
        file_path = Path(input.instruction)
        git = GitManager(file_path.parent)
        git.checkout_branch(f'feature/{input.task_id.replace("/","-")}')
        git.commit_all('feat: AI Implementation')
        return AgentOutput(task_id=input.task_id, result='Committed')
