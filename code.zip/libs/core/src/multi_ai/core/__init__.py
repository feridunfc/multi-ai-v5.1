# libs/core/src/multi_ai/core/__init__.py
"""
MultiAI Enterprise Core Module
Version: 6.2.0
"""

from .settings import settings, PlatformSettings
from .security import KMSManager, SecurityValidator
from .budget import budget_guard, BudgetPolicy
from .audit import audit_logger, SecurityAudit
from .ledger import ledger, ManifestLedger
from .metrics import track_time, LLM_TOKENS, AGENT_REQUESTS, BUDGET_USAGE
from .validator import validator, DeterministicValidator
from .exceptions import BudgetExceededError, SecurityViolationError, LedgerIntegrityError

# Version info
__version__ = "6.2.0"
__author__ = "MultiAI Enterprise Team"
__description__ = "Core components for MultiAI Enterprise platform"

__all__ = [
    # Settings
    'settings', 'PlatformSettings',

    # Security
    'KMSManager', 'SecurityValidator',

    # Budget & Cost
    'budget_guard', 'BudgetPolicy',

    # Audit & Compliance
    'audit_logger', 'SecurityAudit',

    # Ledger & Tracking
    'ledger', 'ManifestLedger',

    # Metrics & Monitoring
    'track_time', 'LLM_TOKENS', 'AGENT_REQUESTS', 'BUDGET_USAGE',

    # Validation
    'validator', 'DeterministicValidator',

    # Exceptions
    'BudgetExceededError', 'SecurityViolationError', 'LedgerIntegrityError',

    # Metadata
    '__version__', '__author__', '__description__'
]


# Package initialization
def init_core():
    """Core modülünü başlat"""
    from . import settings
    from .security import KMSManager

    # Security system initialization
    kms_manager = KMSManager()

    # Audit system ready
    audit_logger.info("MultiAI Core initialized", version=__version__)

    return {
        "status": "initialized",
        "version": __version__,
        "components": {
            "security": "active",
            "budget": "active",
            "ledger": "active",
            "metrics": "active"
        }
    }


# Auto-initialize on import
_CORE_STATUS = init_core()